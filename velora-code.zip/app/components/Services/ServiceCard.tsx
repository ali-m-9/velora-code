import Link from "next/link";
import { LucideIcon } from "lucide-react";

type ServiceCardProps = {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  index: number;
};

export default function ServiceCard({
  title,
  description,
  icon: Icon,
  href,
  index,
}: ServiceCardProps) {
  return (
    <article>
      {/* شماره کارت */}
      <span>{String(index + 1).padStart(2, "0")}</span>

      {/* آیکون */}
      <div>
        <Icon size={36} />
      </div>

      {/* عنوان */}
      <h3>{title}</h3>

      {/* توضیحات */}
      <p>{description}</p>

      {/* لینک */}
      <Link href={href}>
        اطلاعات بیشتر
      </Link>
    </article>
  );
}